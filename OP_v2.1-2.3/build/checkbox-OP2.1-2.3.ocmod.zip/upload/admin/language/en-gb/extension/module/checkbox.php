<?php
// Heading
$_['heading_title']    = 'Checkbox.in.ua';

// Text
$_['text_extension']   = 'Модули';
$_['text_success']     = 'Настройки модуля обновлены!';
$_['text_edit']        = 'Редактирование модуля';

// Entry
$_['entry_status']              = 'Статус';
$_['entry_rro_login']           = 'Логин';
$_['entry_rro_password']        = 'Пароль';
$_['entry_rro_cashbox_key']     = 'Ключ лицензии кассы';

// Error
$_['error_permission'] = 'У вас нет прав для управления этим модулем!';
