<?php
// Heading
$_['heading_title']    = 'Checkbox.in.ua';

// Text
$_['text_extension']   = 'Модули';
$_['text_success']     = 'Настройки модуля обновлены!';
$_['text_edit']        = 'Редактирование модуля';

// Entry
$_['entry_status']              = 'Статус';
$_['entry_rro_login']           = 'Логин';
$_['entry_rro_password']        = 'Пароль';
$_['entry_rro_cashbox_key']     = 'Ключ лицензии кассы';

$_['entry_rro_receipt_header']     = 'Текст над чеком';
$_['entry_rro_receipt_footer']     = 'Текст под чеком';
// Error
$_['error_permission'] = 'У вас нет прав для управления этим модулем!';
